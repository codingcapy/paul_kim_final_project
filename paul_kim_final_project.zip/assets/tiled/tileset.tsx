<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="tileset" tilewidth="12" tileheight="12" tilecount="1024" columns="32">
 <image source="../../../game-project-5 pokemon game/html/tiled/tileset.png" width="384" height="384"/>
</tileset>
